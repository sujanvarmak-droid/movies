import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.join(__dirname, '..');
const dataDir = path.join(root, 'data');
const usersFile = path.join(dataDir, 'users.json');
const moviesFile = path.join(dataDir, 'movies.json');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const users = [
  { id: 'u1', email: 'test@example.com', password: 'Password123!' }
];
const movies = [
  { id: 'm1', title: 'Inception', publishingYear: 2010, posterPath: null },
  { id: 'm2', title: 'The Matrix', publishingYear: 1999, posterPath: null },
  { id: 'm3', title: 'Interstellar', publishingYear: 2014, posterPath: null }
];

fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
fs.writeFileSync(moviesFile, JSON.stringify(movies, null, 2));

console.log('Seeded users and movies.');
