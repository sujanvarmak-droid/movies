import { Router } from 'express';
import { body, param, query, validationResult } from 'express-validator';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { ensureDataFiles, readJSON, writeJSON, moviesFile } from '../utils/fsStore.js';
import { requireAuth } from '../middleware/requireAuth.js';
import { nanoid } from 'nanoid';

ensureDataFiles();

const router = Router();

const uploadDir = path.join(process.cwd(), 'public/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${nanoid(6)}${ext}`);
  }
});
const upload = multer({ storage });

function validate(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
}

router.get('/',
  query('page').optional().isInt({ min: 1 }).toInt(),
  query('pageSize').optional().isInt({ min: 1, max: 100 }).toInt(),
  (req, res) => {
    const errorRes = validate(req, res); if (errorRes) return;
    const page = req.query.page || 1;
    const pageSize = req.query.pageSize || 10;
    const all = readJSON(moviesFile);
    const total = all.length;
    const start = (page - 1) * pageSize;
    const items = all.slice(start, start + pageSize);
    return res.json({ page, pageSize, total, items });
  }
);

router.get('/:id', param('id').notEmpty(), (req, res) => {
  const errorRes = validate(req, res); if (errorRes) return;
  const all = readJSON(moviesFile);
  const movie = all.find(m => m.id === req.params.id);
  if (!movie) return res.status(404).json({ error: 'Movie not found' });
  return res.json(movie);
});

router.post('/', requireAuth,
  upload.single('poster'),
  body('title').isString().isLength({ min: 1 }).withMessage('Title is required'),
  body('publishingYear').isInt({ min: 1800, max: 3000 }).withMessage('Invalid year').toInt(),
  (req, res) => {
    const errorRes = validate(req, res); if (errorRes) return;
    const { title, publishingYear } = req.body;
    const all = readJSON(moviesFile);
    const posterPath = req.file ? `/uploads/${req.file.filename}` : null;
    const movie = { id: nanoid(), title, publishingYear: Number(publishingYear), posterPath };
    all.push(movie);
    writeJSON(moviesFile, all);
    return res.status(201).json(movie);
  }
);

router.put('/:id', requireAuth,
  upload.single('poster'),
  param('id').notEmpty(),
  body('title').isString().isLength({ min: 1 }).withMessage('Title is required'),
  body('publishingYear').isInt({ min: 1800, max: 3000 }).withMessage('Invalid year').toInt(),
  (req, res) => {
    const errorRes = validate(req, res); if (errorRes) return;
    const { title, publishingYear } = req.body;
    const all = readJSON(moviesFile);
    const idx = all.findIndex(m => m.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Movie not found' });

    if (req.file && all[idx].posterPath) {
      try {
        fs.unlinkSync(path.join(process.cwd(), 'public', all[idx].posterPath.replace(/^\//, '')));
      } catch {}
    }
    const posterPath = req.file ? `/uploads/${req.file.filename}` : all[idx].posterPath;

    all[idx] = { ...all[idx], title, publishingYear: Number(publishingYear), posterPath };
    writeJSON(moviesFile, all);
    return res.json(all[idx]);
  }
);

router.delete('/:id', requireAuth, param('id').notEmpty(), (req, res) => {
  const errorRes = validate(req, res); if (errorRes) return;
  const all = readJSON(moviesFile);
  const idx = all.findIndex(m => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Movie not found' });

  const [removed] = all.splice(idx, 1);
  writeJSON(moviesFile, all);
  if (removed.posterPath) {
    try {
      fs.unlinkSync(path.join(process.cwd(), 'public', removed.posterPath.replace(/^\//, '')));
    } catch {}
  }
  return res.json({ success: true });
});

export default router;
