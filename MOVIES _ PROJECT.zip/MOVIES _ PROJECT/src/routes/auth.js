import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { body, validationResult } from 'express-validator';
import { ensureDataFiles, readJSON, writeJSON, usersFile } from '../utils/fsStore.js';
import { nanoid } from 'nanoid';

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const router = Router();

ensureDataFiles();

router.post('/register',
  body('email').isEmail().withMessage('Invalid email'),
  body('password').isLength({ min: 8 }).withMessage('Password too short'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    const users = readJSON(usersFile);
    const exists = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (exists) return res.status(409).json({ error: 'Email already registered' });
    const user = { id: nanoid(), email, password };
    users.push(user);
    writeJSON(usersFile, users);
    return res.status(201).json({ id: user.id, email: user.email });
  }
);

router.post('/login',
  body('email').isEmail().withMessage('Invalid email'),
  body('password').notEmpty().withMessage('Password required'),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    const users = readJSON(usersFile);
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = user.password === password;
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({ token, user: { id: user.id, email: user.email } });
  }
);

export default router;
