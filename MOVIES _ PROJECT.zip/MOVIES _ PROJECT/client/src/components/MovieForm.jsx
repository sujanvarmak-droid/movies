import React, { useEffect, useMemo, useState } from 'react'
import { useDropzone } from 'react-dropzone'

export default function MovieForm({ initial = null, loading = false, error = '', onSubmit, submitLabel = 'Save' }) {
  const [title, setTitle] = useState('')
  const [year, setYear] = useState('')
  const [poster, setPoster] = useState(null)
  const [previewUrl, setPreviewUrl] = useState('')

  useEffect(() => {
    if (initial) {
      setTitle(initial.title || '')
      setYear(initial.publishingYear ? String(initial.publishingYear) : '')
      setPoster(null)
      setPreviewUrl(initial.posterPath || '')
    }
  }, [initial])

  const { getRootProps, getInputProps, isDragActive, acceptedFiles, open } = useDropzone({
    accept: { 'image/*': [] },
    multiple: false,
    noClick: true,
    noKeyboard: true,
    onDrop: (files) => {
      setPoster(files?.[0] || null)
    }
  })

  useEffect(() => {
    if (poster) {
      const url = URL.createObjectURL(poster)
      setPreviewUrl(url)
      return () => URL.revokeObjectURL(url)
    }
  }, [poster])

  async function handleSubmit(e) {
    e.preventDefault()
    if (!title.trim()) return onSubmit?.(null, new Error('Title is required.'))
    const y = Number(year)
    if (!(y >= 1800 && y <= 3000)) return onSubmit?.(null, new Error('Year must be between 1800 and 3000.'))

    const formData = new FormData()
    formData.append('title', title.trim())
    formData.append('publishingYear', String(y))
    if (poster) formData.append('poster', poster)

    onSubmit?.(formData)
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-two-col">
        <div className="card poster-drop" {...getRootProps()}>
          <input {...getInputProps()} />
          {previewUrl ? (
            <img className="poster-img" src={previewUrl} alt="poster preview"
                 onError={(e)=>{ e.currentTarget.src = '/placeholder.png' }} />
          ) : (
            <div className="poster-placeholder" onClick={(e)=>e.stopPropagation()}>
              <div className="poster-icon">⬇️</div>
              <p>{isDragActive ? 'Drop an image here' : 'Drop an image here'}</p>
              <button
                type="button"
                className="secondary"
                onClick={(e)=>{ e.stopPropagation(); open(); }}
              >Upload</button>
              {(poster || acceptedFiles[0]) && (
                <p className="poster-selected">Selected: {(poster || acceptedFiles[0]).name}</p>
              )}
            </div>
          )}
          {previewUrl && (
            <div className="poster-actions" onClick={(e)=>e.stopPropagation()}>
              <button
                type="button"
                className="secondary"
                onClick={(e)=>{ e.stopPropagation(); open(); }}
              >Change</button>
              <button
                type="button"
                className="secondary"
                onClick={(e)=>{ e.stopPropagation(); setPoster(null); setPreviewUrl(initial?.posterPath || ''); }}
              >Remove</button>
            </div>
          )}
        </div>
        <div>
          <label>Title
            <input type="text" value={title} onChange={e=>setTitle(e.target.value)} required placeholder="Title" />
          </label>
          <label>Publishing Year
            <input type="number" min={1800} max={3000} value={year} onChange={e=>setYear(e.target.value)} required placeholder="Publishing year" />
          </label>
          <div className="actions">
            <button type="submit" disabled={loading}>{submitLabel}</button>
          </div>
          {error && <p className="error">{error}</p>}
        </div>
      </div>
    </form>
  )
}
