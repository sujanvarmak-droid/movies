import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { apiJson } from '../api'
export default function Login() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate()
    const location = useLocation()

    async function onSubmit(e) {
        e.preventDefault()
        setError('')
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
            setError('Please enter a valid email.')
            return
        }
        if (password.length < 8) {
            setError('Password must be at least 8 characters.')
            return
        }
        try {
            setLoading(true)
            const res = await apiJson('/auth/login', { method: 'POST', body: { email, password } })
            localStorage.setItem('token', res.token)
            const from = location.state?.from?.pathname || '/'
            navigate(from, { replace: true })
        } catch (e) {
            setError(e.message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="container login-wrap">
            <div className="login-card">
                <div className="login-title">Sign in</div>
                <form onSubmit={onSubmit} className="card">
                    <label>
                        <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="Email" />
                    </label>
                    <label>
                        <input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} placeholder="Password" />
                    </label>
                    <div className="remember">
                        <input id="remember" type="checkbox" disabled />
                        <label htmlFor="remember" style={{ margin: 0 }}>Remember me</label>
                    </div>
                    <button type="submit" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</button>
                    {error && <p className="error">{error}</p>}
                </form>
            </div>
        </div>
    )
}
