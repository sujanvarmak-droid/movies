import React, { useEffect, useMemo, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { useNavigate } from 'react-router-dom'
import { apiForm } from '../api'

export default function Movies() {
  const navigate = useNavigate()
  const [items, setItems] = useState([])
  const [page, setPage] = useState(1)
  const [pageSize] = useState(5)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const [movieId, setMovieId] = useState('')
  const [title, setTitle] = useState('')
  const [year, setYear] = useState('')
  const [poster, setPoster] = useState(null)

  const token = useMemo(() => localStorage.getItem('token'), [])

  useEffect(() => {
    fetchMovies()
  }, [page])

  async function fetchMovies() {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/movies?page=${page}&pageSize=${pageSize}`)
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to load movies')
      setItems(data.items)
      setTotal(data.total)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function startEdit(m) {
    setMovieId(m.id)
    setTitle(m.title)
    setYear(String(m.publishingYear))
    setPoster(null)
    setError('')
  }

  function resetForm() {
    setMovieId('')
    setTitle('')
    setYear('')
    setPoster(null)
    setError('')
  }

  const { getRootProps, getInputProps, isDragActive, acceptedFiles } = useDropzone({
    accept: { 'image/*': [] },
    multiple: false,
    onDrop: (files) => {
      setPoster(files?.[0] || null)
    }
  })

  async function onSubmit(e) {
    e.preventDefault()
    setError('')
    if (!title.trim()) { setError('Title is required.'); return }
    const y = Number(year)
    if (!(y >= 1800 && y <= 3000)) { setError('Year must be between 1800 and 3000.'); return }

    const formData = new FormData()
    formData.append('title', title.trim())
    formData.append('publishingYear', String(y))
    if (poster) formData.append('poster', poster)

    try {
      setLoading(true)
      if (movieId) {
        await apiForm(`/movies/${movieId}`, { method: 'PUT', formData, token })
      } else {
        await apiForm('/movies', { method: 'POST', formData, token })
      }
      resetForm()
      fetchMovies()
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function onDelete(id) {
    if (!confirm('Delete this movie?')) return
    try {
      setLoading(true)
      const res = await fetch(`/api/movies/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.error || 'Delete failed')
      }
      fetchMovies()
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('token')
    navigate('/login')
  }

  const pageCount = Math.max(1, Math.ceil(total / pageSize))

  return (
    <div className="container">
      <header className="header">
        <h1>Movies</h1>
        <div>
          <button className="secondary" onClick={logout}>Logout</button>
        </div>
      </header>

      <section className="card">
        <h2>{movieId ? 'Edit movie' : 'Create a new movie'}</h2>
        <form onSubmit={onSubmit}>
          <label>Title
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} required />
          </label>
          <label>Publishing Year
            <input type="number" min={1800} max={3000} value={year} onChange={e => setYear(e.target.value)} required />
          </label>
          <div className="poster-drop" {...getRootProps()}>
            <input {...getInputProps()} />
            {poster || acceptedFiles[0] ? (
              <div className="poster-selected">Selected: {(poster || acceptedFiles[0]).name}</div>
            ) : (
              <div className="poster-placeholder">
                <div className="poster-icon">⬇️</div>
                <div>Upload an image here</div>
              </div>
            )}
          </div>
          <div className="actions actions-row">
            <button type="button" className="btn-outline" onClick={resetForm}>Cancel</button>
            <button type="submit" disabled={loading}>{movieId ? 'Update' : 'Submit'}</button>
          </div>
          {error && <p className="error">{error}</p>}
        </form>
      </section>

      <section className="card">
        <h2>Movie List</h2>
        {loading && <p>Loading...</p>}
        {!loading && (
          <div>
            {items.map(m => (
              <div key={m.id} className="movie-item">
                <div className="movie-main">
                  <img src={m.posterPath || '/placeholder.png'} alt="poster" onError={(e) => { e.currentTarget.src = '/placeholder.png' }} />
                  <div>
                    <div className="title">{m.title}</div>
                    <div className="year">{m.publishingYear}</div>
                  </div>
                </div>
                <div className="movie-actions">
                  <button onClick={() => startEdit(m)}>Edit</button>
                  <button className="danger" onClick={() => onDelete(m.id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="pagination">
          <button className="secondary" disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>Prev</button>
          <span>Page {page} of {pageCount}</span>
          <button className="secondary" disabled={page >= pageCount} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      </section>
    </div>
  )
}
