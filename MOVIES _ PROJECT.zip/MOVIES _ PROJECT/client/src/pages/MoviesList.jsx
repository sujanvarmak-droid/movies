import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

export default function MoviesList() {
  const navigate = useNavigate()
  const [items, setItems] = useState([])
  const [page, setPage] = useState(1)
  const [pageSize] = useState(8)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchMovies()
  }, [page])

  async function fetchMovies() {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/movies?page=${page}&pageSize=${pageSize}`)
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to load movies')
      setItems(data.items)
      setTotal(data.total)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('token')
    navigate('/login')
  }

  const pageCount = Math.max(1, Math.ceil(total / pageSize))

  async function onDelete(id) {
    if (!confirm('Delete this movie?')) return
    try {
      setLoading(true)
      const token = localStorage.getItem('token')
      const res = await fetch(`/api/movies/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } })
      if (!res.ok) {
        const data = await res.json().catch(()=>({}))
        throw new Error(data.error || 'Delete failed')
      }
      fetchMovies()
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <header className="header">
        <h1>My movies</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/movies/new"><button title="Create Movie">Create Movie</button></Link>
          <button className="secondary" onClick={logout}>Logout</button>
        </div>
      </header>

      {error && <p className="error">{error}</p>}
      {loading && <p>Loading...</p>}
      {!loading && (
        <div className="grid">
          {items.map(m => (
            <Link key={m.id} to={`/movies/${m.id}/edit`} className="movie-card">
              <img
                src={m.posterPath || '/placeholder.png'}
                alt="poster"
                onError={(e)=>{e.currentTarget.src='/placeholder.png'}}
              />
              <div className="meta">
                <div className="title">{m.title}</div>
                <div className="year">{m.publishingYear}</div>
                <div className="actions">
                  <button
                    className="danger"
                    onClick={(e)=>{ e.preventDefault(); e.stopPropagation(); onDelete(m.id) }}
                  >Delete</button>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
      <div style={{
    display: "flex",
    gap: "20px",
    alignItems: "center",
    justifyContent: "center",
    padding: "1rem"
}}>
        <button className="secondary" disabled={page<=1} onClick={()=>setPage(p=>Math.max(1,p-1))}>Prev</button>
        <span>Page {page} of {pageCount}</span>
        <button className="secondary" disabled={page>=pageCount} onClick={()=>setPage(p=>p+1)}>Next</button>
      </div>
    </div>
  )
}
