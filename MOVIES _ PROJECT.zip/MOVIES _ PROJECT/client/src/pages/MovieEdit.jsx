import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { apiForm } from '../api'
import MovieForm from '../components/MovieForm'

export default function MovieEdit() {
  const navigate = useNavigate()
  const { id } = useParams()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [initial, setInitial] = useState(null)
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/movies/${id}`)
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to load movie')
        setInitial(data)
      } catch (e) {
        setError(e.message)
      }
    })()
  }, [id])

  async function handleSubmit(formData, validationError) {
    if (validationError) { setError(validationError.message); return }
    setError('')
    try {
      setLoading(true)
      await apiForm(`/movies/${id}`, { method: 'PUT', formData, token })
      navigate('/')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('token')
    navigate('/login')
  }

  return (
    <div className="container">
      <header className="header">
        <h1>Edit Movie</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="secondary" onClick={()=>navigate('/')}>Back to List</button>
          <button className="secondary" onClick={logout}>Logout</button>
        </div>
      </header>
      <section className="card">
        {initial ? (
          <MovieForm initial={initial} loading={loading} error={error} onSubmit={handleSubmit} submitLabel="Update" />
        ) : (
          <p>Loading...</p>
        )}
      </section>
    </div>
  )
}
