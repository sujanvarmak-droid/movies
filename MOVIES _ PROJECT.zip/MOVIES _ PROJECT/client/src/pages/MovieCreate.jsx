import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import MovieForm from '../components/MovieForm'

export default function MovieCreate() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null
  async function handleSubmit(formData, validationError) {
    if (validationError) { setError(validationError.message); return }
    setError('')
    try {
      setLoading(true)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('token')
    navigate('/login')
  }
  return (
    <div className="container">
      <header className="header">
        <h1>Create Movie</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="secondary" onClick={()=>navigate('/')}>Back to List</button>
          <button className="secondary" onClick={logout}>Logout</button>
        </div>
      </header>
      <section className="card">
        <MovieForm loading={loading} error={error} onSubmit={handleSubmit} submitLabel="Create" />
      </section>

    </div>
  )
}
