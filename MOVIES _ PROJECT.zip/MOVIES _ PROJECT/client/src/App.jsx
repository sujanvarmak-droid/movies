import React from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import Login from './pages/Login'
import MovieCreate from './pages/MovieCreate'
import MovieEdit from './pages/MovieEdit'
import MoviesList from './pages/MoviesList'

function RequireAuth({ children }) {
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null
  const location = useLocation()
  if (!token) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<RequireAuth><MoviesList /></RequireAuth>} />
      <Route path="/movies/new" element={<RequireAuth><MovieCreate /></RequireAuth>} />
      <Route path="/movies/:id/edit" element={<RequireAuth><MovieEdit /></RequireAuth>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
