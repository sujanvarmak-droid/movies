export const API_BASE = '/api'

export async function apiJson(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' }
  if (token) headers['Authorization'] = `Bearer ${token}`
  const res = await fetch(`${API_BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const message = data.error || data?.errors?.[0]?.msg || 'Request failed'
    throw new Error(message)
  }
  return data
}

export async function apiForm(path, { method = 'POST', formData, token } = {}) {
  const headers = {}
  if (token) headers['Authorization'] = `Bearer ${token}`
  const res = await fetch(`${API_BASE}${path}`, { method, headers, body: formData })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const message = data.error || data?.errors?.[0]?.msg || 'Request failed'
    throw new Error(message)
  }
  return data
}
