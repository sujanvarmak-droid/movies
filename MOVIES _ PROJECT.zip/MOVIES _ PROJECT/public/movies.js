const token = localStorage.getItem('token');
if (!token) {
  window.location.href = '/';
}

const listEl = document.getElementById('list');
const pageInfo = document.getElementById('pageInfo');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const form = document.getElementById('movieForm');
const resetBtn = document.getElementById('resetBtn');
const formError = document.getElementById('formError');
const logoutBtn = document.getElementById('logoutBtn');

let page = 1;
const pageSize = 5;

logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('token');
  window.location.href = '/';
});

async function fetchMovies() {
  const res = await fetch(`/api/movies?page=${page}&pageSize=${pageSize}`);
  const data = await res.json();
  renderList(data.items);
  pageInfo.textContent = `Page ${data.page} of ${Math.ceil(data.total / data.pageSize)}`;
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= Math.ceil(data.total / data.pageSize);
}

function renderList(items) {
  listEl.innerHTML = '';
  for (const m of items) {
    const div = document.createElement('div');
    div.className = 'movie-item';
    div.innerHTML = `
      <div class="movie-main">
        <img src="${m.posterPath || '/placeholder.png'}" alt="poster" onerror="this.src='/placeholder.png'" />
        <div>
          <div class="title">${m.title}</div>
          <div class="year">${m.publishingYear}</div>
        </div>
      </div>
      <div class="movie-actions">
        <button data-id="${m.id}" class="edit">Edit</button>
        <button data-id="${m.id}" class="danger delete">Delete</button>
      </div>
    `;
    div.querySelector('.edit').addEventListener('click', () => startEdit(m));
    div.querySelector('.delete').addEventListener('click', () => deleteMovie(m.id));
    listEl.appendChild(div);
  }
}

prevBtn.addEventListener('click', () => { if (page>1){ page--; fetchMovies(); } });
nextBtn.addEventListener('click', () => { page++; fetchMovies(); });

function startEdit(m) {
  document.getElementById('movieId').value = m.id;
  document.getElementById('title').value = m.title;
  document.getElementById('publishingYear').value = m.publishingYear;
  document.getElementById('poster').value = '';
  formError.textContent = '';
}

resetBtn.addEventListener('click', () => {
  document.getElementById('movieId').value = '';
  document.getElementById('title').value = '';
  document.getElementById('publishingYear').value = '';
  document.getElementById('poster').value = '';
  formError.textContent = '';
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  formError.textContent = '';
  const id = document.getElementById('movieId').value;
  const title = document.getElementById('title').value.trim();
  const year = parseInt(document.getElementById('publishingYear').value, 10);
  const poster = document.getElementById('poster').files[0];

  if (!title) { formError.textContent = 'Title is required.'; return; }
  if (!(year >= 1800 && year <= 3000)) { formError.textContent = 'Year must be between 1800 and 3000.'; return; }

  const formData = new FormData();
  formData.append('title', title);
  formData.append('publishingYear', String(year));
  if (poster) formData.append('poster', poster);

  const opts = {
    method: id ? 'PUT' : 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formData
  };

  const url = id ? `/api/movies/${id}` : '/api/movies';
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!res.ok) {
    formError.textContent = data.error || (data.errors && data.errors[0]?.msg) || 'Save failed.';
    return;
  }
  resetBtn.click();
  fetchMovies();
});

async function deleteMovie(id) {
  if (!confirm('Delete this movie?')) return;
  const res = await fetch(`/api/movies/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
  if (res.ok) fetchMovies();
}

fetchMovies();
